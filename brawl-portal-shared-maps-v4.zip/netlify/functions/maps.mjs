import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';

const DEFAULT_MAP = {
  id: 'darryl-parkour',
  name: 'Darryl Parkour',
  description: 'A great map to play with friends',
  url: 'nullsbrawl://createAndJoinRoom?roomname=map:JP99GPLU0:%20229CQG89RJG&friendly=1&%20side=0',
  image: ''
};

function authorized(event) {
  const header = event.headers.authorization || event.headers.Authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const secret = process.env.ADMIN_SECRET;
  if (!secret || !token) return false;
  const [payload, signature] = token.split('.');
  if (!payload || !signature) return false;
  const expected = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  if (signature.length !== expected.length) return false;
  try {
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return false;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return data.exp > Date.now();
  } catch { return false; }
}

export default async (event) => {
  const store = getStore('brawl-portal-data');
  if (event.httpMethod === 'GET') {
    try {
      const maps = await store.get('maps', { type: 'json' });
      return json(200, { maps: Array.isArray(maps) && maps.length ? maps : [DEFAULT_MAP] });
    } catch {
      return json(200, { maps: [DEFAULT_MAP] });
    }
  }
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  if (!authorized(event)) return json(401, { error: 'Unauthorized' });
  try {
    const body = JSON.parse(event.body || '{}');
    if (!Array.isArray(body.maps) || body.maps.length > 100) return json(400, { error: 'Invalid maps list' });
    const maps = body.maps.map((m) => ({
      id: String(m.id || '').slice(0, 100),
      name: String(m.name || '').slice(0, 70),
      description: String(m.description || '').slice(0, 500),
      url: String(m.url || '').slice(0, 1000),
      image: String(m.image || '').slice(0, 1700000)
    }));
    if (maps.some(m => !m.id || !m.name || !/^(https?:\/\/|nullsbrawl:)/i.test(m.url))) return json(400, { error: 'Invalid map data' });
    await store.setJSON('maps', maps);
    return json(200, { maps });
  } catch {
    return json(500, { error: 'Unable to save maps' });
  }
};

function json(statusCode, body) {
  return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify(body) };
}
