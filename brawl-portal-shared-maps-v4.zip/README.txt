Brawl Portal — Maps + Codes + Admin update

Contents:
- index.html: existing portal with Maps screen, numeric Codes keypad, and admin map editor.
- netlify/functions/admin.mjs: validates the admin code on the server and issues an expiring signed token.
- netlify/functions/maps.mjs: reads/writes shared map data using Netlify Blobs.
- netlify.toml and package.json: Netlify function setup.

IMPORTANT: The admin backend will not work until you configure Netlify environment variables:
1. ADMIN_CODE = 0102 (your new admin code).
2. ADMIN_SECRET = a long random secret, at least 32 random characters.
Set both in Netlify Dashboard > Site configuration > Environment variables, then redeploy.
Never put either value in index.html or commit them to GitHub.

Set ADMIN_CODE to the exact string 0102 (keep the leading zero). Set ADMIN_SECRET to a long random secret (at least 32 characters). The initial map is Darryl Parkour and uses the exact nullsbrawl:// link provided in the request. The initial map list is a fallback until a map is saved to Netlify Blobs. Map preview uploads are limited to about 1.2 MB in the browser.

To test locally, use Netlify CLI (not by opening index.html as a file), because functions and Blobs need the Netlify runtime.
